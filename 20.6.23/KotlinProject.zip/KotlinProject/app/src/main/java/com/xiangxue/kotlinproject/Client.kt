package com.xiangxue.kotlinproject

fun main() {
    LoadingDialog.show1()
}