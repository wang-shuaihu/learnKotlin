package com.xiangxue.kotlinproject;

public class Client {

    // 构造代码块
    {

    }

    void test() {

        LoadingDialog.INSTANCE.show1();

        LoadingDialog.show2();

    }

}
