package com.xiangxue.lib.kt.s01

class KtStudent {
}