package com.xiangxue.lib.java.cb;

public interface JavaCallback {

    void show(String info);

}
