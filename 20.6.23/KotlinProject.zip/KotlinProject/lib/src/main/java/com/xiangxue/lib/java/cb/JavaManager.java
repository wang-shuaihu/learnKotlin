package com.xiangxue.lib.java.cb;

public class JavaManager {

    public void setCallback(JavaCallback javaCallback) {
        javaCallback.show("Derry1");
    }

}
