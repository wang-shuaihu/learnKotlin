package com.xiangxue.lib.java.s01;

import com.xiangxue.lib.kt.s01.MyUtils;

public class Client {

    public static void main(String[] args) {

        // MyUtilsKt.show("Derry1");

        new MyUtils().show("new Derry2");
    }

}
