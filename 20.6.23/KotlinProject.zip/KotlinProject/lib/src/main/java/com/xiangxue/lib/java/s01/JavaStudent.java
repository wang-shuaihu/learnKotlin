package com.xiangxue.lib.java.s01;

public class JavaStudent {

    public static String in = "INNNNNN";

    public String getString() {
        return null;
    }
}
