package com.xiangxue.lib.kt.cb

class KtManager {

    fun setCallback(callback: KTCallback) {
        callback.show("Kt Derry")
    }

}