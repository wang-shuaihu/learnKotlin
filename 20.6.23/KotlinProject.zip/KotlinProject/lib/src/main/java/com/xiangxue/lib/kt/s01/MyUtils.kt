package com.xiangxue.lib.kt.s01

class MyUtils {

    fun show(info: String) {
        println(info)
    }

}

// MyUtils.kt 写了一个show      MyUtilsKt
fun show(info: String) {
    println(info)
}

fun test() {

}

