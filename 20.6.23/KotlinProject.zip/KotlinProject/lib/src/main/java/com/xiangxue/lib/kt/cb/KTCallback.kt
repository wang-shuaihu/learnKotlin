package com.xiangxue.lib.kt.cb

interface KTCallback {

    fun show(name: String)

}